import React from 'react'

export default function Card(props) {
  return (
    <>
      <div className="card text-center">
        <div className="card-body">
          <img src={props.img} alt="" className="card-img" width={"250"} height={"250"} />
          <h3 className="card-tittle">{props.tittle}</h3>
          <p className="card-text">{props.weight}</p>
          <p className="card-text">{props.length}</p>

          <p className="card-text">
            <strike className="text-muted"> Rs. {props.dis}</strike>
            Rs.{props.amt}
          </p>
          <button className="btn btn-info w-100">Add to Card</button>
        </div>
      </div>
    </>
  );
}
