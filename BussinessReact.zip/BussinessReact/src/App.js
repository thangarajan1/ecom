import './App.css';
import Home from './Home';
import Navbar from './Navbar';
import { BrowserRouter,Route,Routes } from 'react-router-dom';
import Birds from './Birds';
import Animals from "./Animals"
import Fishs from "./Fishs"
import Foods from "./Foods"
import Contact from "./Contact"
import Login from './Login';
// import About from "./About"

function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/bird" element={<Birds />} />
          <Route path="/animal" element={<Animals />} />
          <Route path="/fish" element={<Fishs />} />
          <Route path="/food" element={<Foods />} />
          {/* <Route path="/about" element={<About />} /> */}
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
