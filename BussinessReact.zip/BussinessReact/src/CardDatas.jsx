// Birds Images

import b1 from "./Birds/1.jpeg";
import b2 from "./Birds/2.webp";
import b3 from "./Birds/3.jpeg";
import b4 from "./Birds/4.jpg";
import b5 from "./Birds/5.jpg";
import b6 from "./Birds/6.jpg";
import b7 from "./Birds/7.jpg";
import b8 from "./Birds/8.jpg";
import b9 from "./Birds/9.jpg";

// Animals Images

import a1 from "./AnimalPic/1.jpg"
import a2 from "./AnimalPic/2.jpg";
import a3 from "./AnimalPic/3.jpg";
import a4 from "./AnimalPic/4.jpg";
import a5 from "./AnimalPic/5.jpg";
import a6 from "./AnimalPic/6.jpg";
import a7 from "./AnimalPic/7.jpg";
import a8 from "./AnimalPic/8.jpg";
import a9 from "./AnimalPic/9.jpg";

//Fish Images

import fi1 from "./FishPic/1.jpg"
import fi2 from "./FishPic/2.jpg";
import fi3 from "./FishPic/3.jpg"
import fi4 from "./FishPic/4.jpg";
import fi5 from "./FishPic/5.jpg";
import fi6 from "./FishPic/6.jpg";
import fi7 from "./FishPic/7.jpg";
import fi8 from "./FishPic/8.jpg";
import fi9 from "./FishPic/9.jpg";

//Birds Food

import bf1 from "./Food/BirdsFood/1.webp"
import bf2 from "./Food/BirdsFood/2.webp"
import bf3 from "./Food/BirdsFood/3.webp";
import bf4 from "./Food/BirdsFood/4.webp";
import bf5 from "./Food/BirdsFood/5.webp";
import bf6 from "./Food/BirdsFood/6.webp";
import bf7 from "./Food/BirdsFood/7.webp";
import bf8 from "./Food/BirdsFood/8.webp";
import bf9 from "./Food/BirdsFood/9.webp";


export default [
  // Birds

  {
    img: [b1, b2, b3, b4, b5, b6, b7, b8, b9],
    tittle: [
      "Love Birds",
      "Parakeets",
      "Cockatiels",
      "Doves",
      "Canaries",
      "Hyacinth Macaws",
      "African Grey Parrots",
      "Pionus Parrots",
      "Green-Cheeked Conures",
    ],
    weight: [
      "Weight : 2 Ounces",
      "Weight : 1 Ounces",
      "Weight : 1 Ounces",
      "Weight : 5 to 8 Ounces",
      "Weight : Less Than 1 Ounces",
      "Weight : 42 to 51 Ounces",
      "Weight : 15 to 18 Ounces",
      "Weight : 8 to 9 Ounces",
      "Weight : 1 Ounces",
    ],
    length: [
      "Length : 5 to 6 Inches ",
      "Length : 6 to 8 Inches ",
      "Length : 12 to 13 Inches ",
      "Length : 11 to 13 Inches ",
      "Length : 4 to 8 Inches ",
      "Length : 40 Inches ",
      "Length : 13 Inches ",
      "Length : 11 Inches ",
      "Length : 10 to 11 Inches ",
    ],
    dis: [
      "5500",
      "700",
      "4000",
      "500",
      "800",
      "16 Laks",
      "30,000",
      "1300",
      "9500",
    ],
    amt: [
      "4399",
      "500",
      "3700",
      "350",
      "700",
      "13 Laks",
      "25000",
      "1200",
      "9300",
    ],
  },
  {
    img: [a1, a2, a3, a4, a5, a6, a7, a8, a9],
    tittle: [
      "Dogs",
      "Cats",
      "Rabbits",
      "Guinea Pigs",
      "Humsters",
      "Turtle",
      "Horse",
      "Cow",
      "Goat",
    ],
    weight: [],
    length: [],
    dis: [
      "2000",
      "1500",
      "700",
      "350",
      "3099",
      "12000",
      "1.5 Laks",
      "45000",
      "8000",
    ],
    amt: [
      "1799",
      "1299",
      "599",
      "300",
      "2599",
      "10099",
      "1.2 Laks",
      "42000",
      "6500",
    ],
  },
  {
    img: [fi1, fi2, fi3, fi4, fi5, fi6, fi7, fi8, fi9],
    tittle: [
      "Angelfish",
      "Fancy Guppies",
      "Mollies",
      "Tiger Barbs",
      "Clownfish",
      "Convict Cichlids",
      "Mbuna Cichlids",
      "Goldfish",
      "The Betta",
    ],
    weight: [],
    length: [],
    dis: ["150", "95", "90", "50", "3500", "150", "200", "40", "230"],
    amt: ["100", "75", "70", "25", "3100", "120", "150", "30", "190"],
  },
  {
    img: [bf1, bf2, bf3, bf4, bf5, bf6, bf7, bf8, bf9],
    tittle: [
      "JiMMy Pride Parrot Food",
      "JiMMy Panchee Pick Love Bird Food",
      "Boltz Striped Sunflower Seeds Bird Food",
      "Henlo Baked Dry Food for Adult Dogs",
      "Royal Canin Maxi Puppy Dog Dry Food",
      "Drools Optimum Performance Adult Dog",
      "Tetra Rubin Flakes ",
      "Teraa Hara Cichlid Food",
      "Hikari Cichlid Gold Mini",
    ],
    weight: ["SAVE 20%"],
    length: [
      "₹61/100g",
      "₹24/100g ",
      "₹40/100g",
      "₹64/100g",
      "₹70/100g",
      "₹13/100g ",
      "250 ml",
      "200 Gm",
      "57 gm",
    ],
    dis: ["690", "415", "400", "13000", "8500", "3100", "465", "800","290"],
    amt: ["552", "290", "350", "12000", "6300", "2799", "425", "720","240"],
  },
];
