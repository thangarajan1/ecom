import React from 'react'

export default function About() {
  return (
    <>
    
    <h1 className='text-center'>About- Us</h1>
    <div className="container">
      <div className="row">
        <div className="col-md-6">
<div className="card">
  <div className="card-body">
    <img src="" alt="" className="card-img" />
  </div>
</div>
        </div>
        <div className="col-md-6">

        </div>
      </div>
    </div>
    </>
  )
}
