import React from 'react'
import Card from './Card'
import data from "./CardDatas"

export default function Fishs() {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <Card
              img={data[2].img[0]}
              tittle={data[2].tittle[0]}
              weight={data[2].weight[0]}
              length={data[2].length[0]}
              dis={data[2].dis[0]}
              amt={data[2].amt[0]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[2].img[1]}
              tittle={data[2].tittle[1]}
              weight={data[2].weight[1]}
              length={data[2].length[1]}
              dis={data[2].dis[1]}
              amt={data[2].amt[1]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[2].img[2]}
              tittle={data[2].tittle[2]}
              weight={data[2].weight[2]}
              length={data[2].length[2]}
              dis={data[2].dis[2]}
              amt={data[2].amt[2]}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-4">
            <Card
              img={data[2].img[3]}
              tittle={data[2].tittle[3]}
              weight={data[2].weight[3]}
              length={data[2].length[3]}
              dis={data[2].dis[3]}
              amt={data[2].amt[3]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[2].img[4]}
              tittle={data[2].tittle[4]}
              weight={data[2].weight[4]}
              length={data[2].length[4]}
              dis={data[2].dis[4]}
              amt={data[2].amt[4]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[2].img[5]}
              tittle={data[2].tittle[5]}
              weight={data[2].weight[5]}
              length={data[2].length[5]}
              dis={data[2].dis[5]}
              amt={data[2].amt[5]}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-4">
            <Card
              img={data[2].img[6]}
              tittle={data[2].tittle[6]}
              weight={data[2].weight[6]}
              length={data[2].length[6]}
              dis={data[2].dis[6]}
              amt={data[2].amt[6]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[2].img[7]}
              tittle={data[2].tittle[7]}
              weight={data[2].weight[7]}
              length={data[2].length[7]}
              dis={data[2].dis[7]}
              amt={data[2].amt[7]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[2].img[8]}
              tittle={data[2].tittle[8]}
              weight={data[2].weight[8]}
              length={data[2].length[8]}
              dis={data[2].dis[8]}
              amt={data[2].amt[8]}
            />
          </div>
        </div>
      </div>
    </>
  );
}
