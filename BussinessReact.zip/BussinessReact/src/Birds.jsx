import React from 'react'
import Card from './Card';
import data from "./CardDatas"

export default function Birds() {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <Card
              img={data[0].img[0]}
              tittle={data[0].tittle[0]}
              weight={data[0].weight[0]}
              length={data[0].length[0]}
              dis={data[0].dis[0]}
              amt={data[0].amt[0]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[0].img[1]}
              tittle={data[0].tittle[1]}
              weight={data[0].weight[1]}
              length={data[0].length[1]}
              dis={data[0].dis[1]}
              amt={data[0].amt[1]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[0].img[2]}
              tittle={data[0].tittle[2]}
              weight={data[0].weight[2]}
              length={data[0].length[2]}
              dis={data[0].dis[2]}
              amt={data[0].amt[2]}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-4">
            <Card
              img={data[0].img[8]}
              tittle={data[0].tittle[3]}
              weight={data[0].weight[3]}
              length={data[0].length[3]}
              dis={data[0].dis[3]}
              amt={data[0].amt[3]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[0].img[3]}
              tittle={data[0].tittle[4]}
              weight={data[0].weight[4]}
              length={data[0].length[4]}
              dis={data[0].dis[4]}
              amt={data[0].amt[4]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[0].img[4]}
              tittle={data[0].tittle[5]}
              weight={data[0].weight[5]}
              length={data[0].length[5]}
              dis={data[0].dis[5]}
              amt={data[0].amt[5]}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-4">
            <Card
              img={data[0].img[5]}
              tittle={data[0].tittle[6]}
              weight={data[0].weight[6]}
              length={data[0].length[6]}
              dis={data[0].dis[6]}
              amt={data[0].amt[6]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[0].img[7]}
              tittle={data[0].tittle[7]}
              weight={data[0].weight[7]}
              length={data[0].length[7]}
              dis={data[0].dis[7]}
              amt={data[0].amt[7]}
            />
          </div>
          <div className="col-md-4">
            <Card
              img={data[0].img[6]}
              tittle={data[0].tittle[8]}
              weight={data[0].weight[8]}
              length={data[0].length[8]}
              dis={data[0].dis[8]}
              amt={data[0].amt[8]}
            />
          </div>
        </div>
      </div>
    </>
  );
}
