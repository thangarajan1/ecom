import React from 'react'
import img from "./home.png"

export default function Home() {
  return (
    <img
src={img}
    alt=""
      width={"100%"}
      height={"500"}
    />
  );
}
